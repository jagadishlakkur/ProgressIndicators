package com.jagadish.progressindicators2;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;

public class ProgressBars {

    Context context;
    static  ProgressDialog progressDialog;
    static Dialog dialog;
    static  Dialog anim_dialog;
    static Dialog bubble_dialog;

    public static void displayProgressDailog(Context context)
    {

        progressDialog=new ProgressDialog(context);
        progressDialog.setMessage("Loading..");
        progressDialog.show();

    }

    public static void displayProgressDailog(Context context,String message)
    {

        progressDialog=new ProgressDialog(context);
        progressDialog.setMessage(message);
        progressDialog.show();

    }

    public static void displayProgressDailog(Context context,String message,boolean cancelable)
    {

        progressDialog=new ProgressDialog(context);
        progressDialog.setMessage(message);
        progressDialog.setCancelable(cancelable);
        progressDialog.show();

    }

    public static void dismissProgressDailog()
    {

        progressDialog.dismiss();

    }


    public static void displayCustomProgress(Context context)
    {

        dialog = new Dialog(context, android.R.style.Theme_Black);
        View view2 = LayoutInflater.from(context).inflate(R.layout.background, null);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawableResource(R.color.transparent2);
        dialog.setContentView(view2);
        dialog.show();

    }

    public static void dismissCustomProgress()
    {

        dialog.dismiss();

    }


}
